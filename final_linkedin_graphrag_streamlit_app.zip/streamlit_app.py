# import streamlit as st
# from utils.graphqueries import (
#     parse_query_with_groq,
#     get_people_from_graph,
#     run_dynamic_graph_query,
#     show_jobs_for_streamlit
# )
# from utils.memory import (
#     add_user_message,
#     add_ai_message,
#     get_memory_messages
# )
# import json

# st.set_page_config(page_title="LinkedIn GraphRAG", layout="wide")

# # --- Sidebar: Conversation Memory ---
# st.sidebar.title("🧠 Conversation Memory")
# messages = get_memory_messages()
# for msg in messages:
#     role = "User" if msg.type == "human" else "AI"
#     st.sidebar.markdown(f"**{role}:** {msg.content}")

# # --- Main Title ---
# st.title("💼 LinkedIn GraphRAG")

# st.success("✅ Streamlit app is running correctly!")

# # --- User Input ---
# user_query = st.text_input("Ask something about your LinkedIn network:", "")

# if user_query:
#     st.markdown(f"🔍 You asked: **{user_query}**")

#     # Add to memory
#     add_user_message(user_query)

#     try:
#         parsed_query = parse_query_with_groq(user_query)

#         if isinstance(parsed_query, list):
#             parsed_query = parsed_query[0]

#         role = parsed_query.get("role")
#         degree = parsed_query.get("degree")
#         company = parsed_query.get("company")

#         st.markdown(
#             f"#### 🧠 Interpreted Query ➜ "
#             f"**Role:** `{role or 'None'}`, **Degree:** `{degree or 'None'}`, **Company:** `{company or 'None'}`"
#         )

#         add_ai_message(json.dumps(parsed_query))

#         # --- Logic: Handle query types ---
#         if role and not company and "similar" in user_query.lower():
#             st.subheader("🔍 Finding people with similar roles...")
#             from utils.graphqueries import find_similar_people
#             matches = find_similar_people(role, degree)
#             if matches:
#                 for person in matches:
#                     st.markdown(
#                         f"👉 **{person['name']}** - {person['position']} @ {person['company']} "
#                         f"(Similarity: {person['similarity']}%)"
#                     )
#                     st.markdown(f"🔗 [LinkedIn]({person['url']})" if person["url"] != "Not available" else "🔗 LinkedIn: Not available")
#                     st.divider()
#                     if st.toggle(f"💼 Show jobs at {person['company']}", key=f"jobs_{person['company']}"):
#                         show_jobs_for_streamlit(person["company"], role)
#             else:
#                 st.warning("⚠️ No similar people found in your network.")

#         elif company and role:
#             run_dynamic_graph_query(parsed_query, streamlit=True)

#         elif company and not role:
#             st.subheader(f"🔎 Finding people in your network working at {company}...")
#             get_people_from_graph(company, degree, streamlit=True)
#             if st.toggle(f"💼 Show jobs at {company}", key=f"jobs_{company}_people_only"):
#                 show_jobs_for_streamlit(company, role)

#         else:
#             st.info("ℹ️ Please provide at least a company name or a role to continue.")

#     except Exception as e:
#         st.error(f"❌ Error: {e}")

import streamlit as st
from utils.graphqueries import (
    parse_query_with_groq,
    run_dynamic_graph_query,
    find_similar_people,
    run_adzuna_job_search
)
from graphrag import graphrag_query  # ✅ Hybrid logic with similarity + degree

st.set_page_config(page_title="LinkedIn GraphRAG", page_icon="🔍")
st.title("🔍 LinkedIn GraphRAG")

user_query = st.text_input("Ask me anything about your LinkedIn network:")

if user_query:
    st.markdown(f"🧠 You asked: **{user_query}**")

    try:
        parsed = parse_query_with_groq(user_query)

        role = parsed.get("role")
        degree = parsed.get("degree")
        company = parsed.get("company")

        st.markdown("### 🔎 Interpreted Query")
        st.json(parsed)

        # --- Case 1: Similar role (no company)
        if role and "similar" in user_query.lower() and not company:
            st.markdown("### 👥 Finding similar roles in your network...")
            matches = find_similar_people(role, degree or 2)
            for person in matches:
                st.markdown(f"**{person['name']}** - {person['position']} @ {person['company']} (Similarity: {person['similarity']}%)")
                st.markdown(f"🔗 LinkedIn: {person['url']}")
                st.divider()

        # --- Case 2: Company and role provided
        elif company and role:
            run_dynamic_graph_query(parsed_query=parsed, streamlit=True)

        # --- Case 3: Only company provided → use hybrid similarity
        elif company and not role:
            st.markdown("### 🤝 Matching People in Your Network (with Similarity Scores)")
            results = graphrag_query("Atharva Chouthai", company, degree or 3)
            if results:
                for person in results:
                    st.markdown(f"**{person['name']}** - {person['position']} @ {person['company']}")
                    st.markdown(f"🔗 [LinkedIn]({person['url']})")
                    st.markdown(
                        f"📈 **Similarity Score:** {person['similarity_score']}% &nbsp; | &nbsp;"
                        f"🔗 **Degree:** {person['degree']}° &nbsp; | &nbsp;"
                        f"⚡ **Hybrid Score:** {person['hybrid_score']}"
                    )
                    st.divider()
            else:
                st.warning(f"⚠️ No similar people found at {company}.")

        else:
            st.warning("❗ Please provide at least a company name or role to search.")

        # --- Ask if user wants to search for jobs
        st.markdown("### 💼 Would you like to find related job openings?")
        if st.toggle("🔍 Yes, show me jobs using Adzuna API"):
            job_role = st.text_input("🔧 Role (e.g., Software Engineer)")
            job_location = st.text_input("📍 Location (e.g., New York, Boston)")
            job_company = st.text_input("🏢 Company (optional)")

            if st.button("🔎 Search Jobs"):
                if not job_role or not job_location:
                    st.warning("Please enter both role and location to search.")
                else:
                    with st.spinner("Searching for jobs..."):
                        jobs = run_adzuna_job_search(
                            company=job_company,
                            role=job_role,
                            location=job_location
                        )
                        if jobs:
                            st.success(f"Found {len(jobs)} job(s):")
                            for job in jobs:
                                st.markdown(f"**{job['title']}** at *{job['company']}*")
                                st.markdown(f"📍 {job['location']}")
                                st.markdown(f"🔗 [Apply here]({job['url']})")
                                st.divider()
                        else:
                            st.info("No jobs found for your criteria.")

    except Exception as e:
        st.error(f"❌ Error: {e}")