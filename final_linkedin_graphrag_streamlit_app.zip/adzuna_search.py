# adzuna_api.py
import os
import requests
from dotenv import load_dotenv

load_dotenv()

ADZUNA_APP_ID = os.getenv("ADZUNA_APP_ID")
ADZUNA_APP_KEY = os.getenv("ADZUNA_APP_KEY")


def run_adzuna_job_search(role, location, company=None, level=None, results=5):
    base_url = "https://api.adzuna.com/v1/api/jobs/us/search/1"
    params = {
        "app_id": ADZUNA_APP_ID,
        "app_key": ADZUNA_APP_KEY,
        "results_per_page": results,
        "what": role,
        "where": location,
        "content-type": "application/json",
    }

    if company:
        params["company"] = company

    response = requests.get(base_url, params=params)
    response.raise_for_status()
    jobs = response.json().get("results", [])

    if level:
        jobs = [job for job in jobs if level.lower() in job.get("title", "").lower()]

    return jobs
